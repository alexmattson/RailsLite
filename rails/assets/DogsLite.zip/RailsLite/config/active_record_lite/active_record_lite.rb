require_relative 'sql_object.rb'
require 'active_support/inflector'
